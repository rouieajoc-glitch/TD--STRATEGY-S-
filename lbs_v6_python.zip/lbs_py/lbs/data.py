"""Candle loader: Binance spot (default, works from GitHub Codespaces), Binance USDT-M futures, or your own CSV.

Codespaces usually run in US data centres, and Binance blocks the US on api.binance.com / fapi.binance.com
(HTTP 451). data-api.binance.vision is Binance's public market-data mirror and is not blocked, so
'spot' is the default source. Use --source futures if you run it outside the US.
"""
from __future__ import annotations

import os
import time

import numpy as np
import pandas as pd

SPOT_URL = "https://data-api.binance.vision/api/v3/klines"
FUT_URL = "https://fapi.binance.com/fapi/v1/klines"

DEFAULT_COINS = ["BTC", "ETH", "ADA", "DOT", "KSM", "MOVR", "ALGO", "SHIB", "NEAR", "RSR"]

# futures symbols that differ from <COIN>USDT
FUT_ALIASES = {"SHIB": "1000SHIBUSDT", "PEPE": "1000PEPEUSDT", "BONK": "1000BONKUSDT", "FLOKI": "1000FLOKIUSDT"}

DATA_DIR = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "data")


def symbol_for(coin: str, source: str) -> str:
    coin = coin.upper()
    if coin.endswith("USDT"):
        return coin
    if source == "futures" and coin in FUT_ALIASES:
        return FUT_ALIASES[coin]
    return coin + "USDT"


def _download(symbol: str, interval: str, source: str, start: str = "2017-01-01") -> pd.DataFrame:
    import requests  # only needed when downloading

    url = SPOT_URL if source == "spot" else FUT_URL
    limit = 1000 if source == "spot" else 1500
    start_ms = int(pd.Timestamp(start, tz="UTC").timestamp() * 1000)
    rows = []
    while True:
        r = requests.get(url, params=dict(symbol=symbol, interval=interval, startTime=start_ms, limit=limit), timeout=30)
        if r.status_code == 451:
            raise RuntimeError(f"{url} is blocked from this location (HTTP 451). Use --source spot.")
        r.raise_for_status()
        data = r.json()
        if not data:
            break
        rows.extend(data)
        start_ms = data[-1][0] + 1
        if len(data) < limit:
            break
        time.sleep(0.15)
    if not rows:
        raise RuntimeError(f"no candles for {symbol} {interval} from {source}")
    df = pd.DataFrame(rows).iloc[:, :7]
    df.columns = ["time", "open", "high", "low", "close", "volume", "close_time"]
    now_ms = int(time.time() * 1000)
    df = df[df["close_time"].astype("int64") < now_ms]          # drop the candle that is still open
    df["time"] = pd.to_datetime(df["time"].astype("int64"), unit="ms")
    for col in ["open", "high", "low", "close", "volume"]:
        df[col] = df[col].astype(float)
    return df[["time", "open", "high", "low", "close", "volume"]].reset_index(drop=True)


def synthetic(coin: str, interval: str = "1d", bars: int = 2500, seed: int | None = None) -> pd.DataFrame:
    """Random trending price series - only for testing that everything runs."""
    rng = np.random.default_rng(abs(hash((coin, interval))) % 2**32 if seed is None else seed)
    regime = np.repeat(rng.normal(0, 0.004, bars // 120 + 1), 120)[:bars]
    ret = regime + rng.standard_t(4, bars) * 0.025
    close = 10 * np.exp(np.cumsum(ret))
    open_ = np.r_[close[0], close[:-1]]
    spread = np.abs(rng.normal(0, 0.015, bars)) * close
    high = np.maximum(open_, close) + spread
    low = np.minimum(open_, close) - np.abs(rng.normal(0, 0.015, bars)) * close
    freq = {"1d": "1D", "4h": "4h", "1h": "1h"}.get(interval, "1D")
    t = pd.date_range("2019-01-01", periods=bars, freq=freq)
    return pd.DataFrame(dict(time=t, open=open_, high=high, low=low, close=close, volume=1.0))


def load(coin: str, interval: str = "1d", source: str = "spot", refresh: bool = False) -> pd.DataFrame:
    """Return candles for one coin. Cached in data/<source>_<SYMBOL>_<interval>.csv.
    source='csv' reads data/<SYMBOL>_<interval>.csv that you put there yourself
    (columns: time,open,high,low,close[,volume]; time in UTC)."""
    if source == "synthetic":
        return synthetic(coin, interval)
    os.makedirs(DATA_DIR, exist_ok=True)
    sym = symbol_for(coin, "futures" if source == "futures" else "spot")
    if source == "csv":
        path = os.path.join(DATA_DIR, f"{sym}_{interval}.csv")
        df = pd.read_csv(path)
        df["time"] = pd.to_datetime(df["time"], utc=True).dt.tz_localize(None)
        return df.sort_values("time").reset_index(drop=True)
    path = os.path.join(DATA_DIR, f"{source}_{sym}_{interval}.csv")
    if os.path.exists(path) and not refresh:
        df = pd.read_csv(path, parse_dates=["time"])
        last = df["time"].iloc[-1]
        # top up with new candles
        try:
            new = _download(sym, interval, source, start=str(last + pd.Timedelta(seconds=1)))
            df = pd.concat([df, new]).drop_duplicates("time").sort_values("time").reset_index(drop=True)
            df.to_csv(path, index=False)
        except Exception as e:  # offline or nothing new: use the cache
            if "no candles" not in str(e):
                print(f"  ({sym}: could not update cache: {e})")
        return df
    df = _download(sym, interval, source)
    df.to_csv(path, index=False)
    return df

"""Shared helpers for the CLIs: load a basket once, cache features, evaluate a config."""
from __future__ import annotations

import argparse
from dataclasses import fields, replace
import os
import sys

import pandas as pd

from .engine import StructParams, LBParams, TradeParams, build_features, simulate
from .stats import trade_stats, basket_summary
from .data import load


class Basket:
    def __init__(self, coins, interval="1d", source="spot", refresh=False, quiet=False):
        self.interval = interval
        self.data = {}
        for coin in coins:
            try:
                df = load(coin, interval, source, refresh)
                self.data[coin] = df
                if not quiet:
                    print(f"  {coin:6s} {len(df):6d} candles  {df['time'].iloc[0]:%Y-%m-%d} -> {df['time'].iloc[-1]:%Y-%m-%d}")
            except Exception as e:
                print(f"  {coin:6s} SKIPPED: {e}", file=sys.stderr)
        self._feat = {}

    def features(self, coin: str, sp: StructParams, lp: LBParams = LBParams()):
        key = (coin, sp, lp)
        if key not in self._feat:
            self._feat[key] = build_features(self.data[coin], sp, lp)
        return self._feat[key]

    def run(self, tp: TradeParams, sp: StructParams = StructParams(), start=None, end=None, keep_trades=False):
        rows, trades = [], []
        for coin in self.data:
            res = simulate(self.features(coin, sp), tp, start, end)
            st = trade_stats(res)
            st = {"coin": coin, **st}
            rows.append(st)
            if keep_trades:
                for t in res["trades"]:
                    trades.append({"coin": coin, **t})
        per = pd.DataFrame(rows)
        return per, basket_summary(per), pd.DataFrame(trades)


def add_param_args(ap: argparse.ArgumentParser):
    """Every TradeParams / StructParams field becomes a --flag (underscores -> dashes)."""
    g = ap.add_argument_group("strategy settings (defaults = LB-S v6 Pine defaults)")
    for cls in (StructParams, TradeParams):
        for f in fields(cls):
            flag = "--" + f.name.replace("_", "-")
            if f.type in ("bool", bool):
                g.add_argument(flag, type=lambda s: s.lower() in ("1", "true", "yes", "on"), default=None,
                               metavar="true/false")
            else:
                typ = {"int": int, "float": float, "str": str}.get(str(f.type), str)
                g.add_argument(flag, type=typ, default=None)


def params_from_args(args, base_tp=TradeParams(), base_sp=StructParams()):
    tp_kw = {f.name: getattr(args, f.name) for f in fields(TradeParams) if getattr(args, f.name, None) is not None}
    sp_kw = {f.name: getattr(args, f.name) for f in fields(StructParams) if getattr(args, f.name, None) is not None}
    return replace(base_tp, **tp_kw), replace(base_sp, **sp_kw)


def out_dir(name: str) -> str:
    d = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "results", name)
    os.makedirs(d, exist_ok=True)
    return d


SHOW_COLS = ["coin", "trades", "long_w", "long_be", "long_l", "short_w", "short_be", "short_l", "win_pct", "be_pct",
             "net_r", "net_long", "net_short", "net_wo_best", "pf", "exp_r", "avg_win", "best_r", "max_dd",
             "no_win_run", "open_n", "unreal_r"]


def print_table(per: pd.DataFrame, title: str):
    print(f"\n=== {title} ===")
    if per.empty:
        print("(no data)")
        return
    with pd.option_context("display.width", 250, "display.max_columns", 50):
        print(per[SHOW_COLS].to_string(index=False))


def print_basket(b: dict, title="BASKET"):
    if not b:
        return
    print(f"--- {title}: {b['coins']} coins | {b['trades']} trades | net {b['net_r']}R "
          f"(long {b['net_long']} / short {b['net_short']}) | without each coin's best trade {b['sum_wo_best']}R | "
          f"positive w/o best {b['pos_wo_best']}/{b['coins']} | median exp {b['median_exp']}R | "
          f"worst DD {b['worst_dd']}R | worst no-win run {b['worst_no_win']}")

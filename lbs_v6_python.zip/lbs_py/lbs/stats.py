"""Stats identical to the LB-S v6 table, plus basket aggregation."""
from __future__ import annotations

import numpy as np
import pandas as pd


def trade_stats(res: dict) -> dict:
    tr = res["trades"]
    r = np.array([t["r"] for t in tr], float)
    d = np.array([t["dir"] for t in tr], int)
    n = len(r)
    win = r >= 0.5
    loss = r <= -0.5
    be = ~win & ~loss
    gross_w = r[r > 0].sum()
    gross_l = -r[r <= 0].sum()
    net = r.sum()
    best = r.max() if n else 0.0
    best = max(best, 0.0)  # Pine bestR starts at 0
    eq = np.cumsum(r) if n else np.array([0.0])
    peak = np.maximum.accumulate(np.r_[0.0, eq])
    max_dd = float((peak - np.r_[0.0, eq]).max())
    run = mx = 0
    for x in r:
        run = 0 if x >= 0.5 else run + 1
        mx = max(mx, run)
    op = res["open"]
    c = res["counts"]
    return dict(
        trades=n,
        long_w=int((win & (d == 1)).sum()), long_be=int((be & (d == 1)).sum()), long_l=int((loss & (d == 1)).sum()),
        short_w=int((win & (d == -1)).sum()), short_be=int((be & (d == -1)).sum()), short_l=int((loss & (d == -1)).sum()),
        win_pct=round(win.mean() * 100, 1) if n else np.nan,
        be_pct=round(be.mean() * 100, 1) if n else np.nan,
        net_r=round(net, 2),
        net_long=round(r[d == 1].sum(), 2), net_short=round(r[d == -1].sum(), 2),
        net_wo_best=round(net - best, 2),
        pf=round(gross_w / gross_l, 2) if gross_l > 0 else np.nan,
        exp_r=round(net / n, 3) if n else np.nan,
        avg_win=round(gross_w / win.sum(), 2) if win.sum() else np.nan,
        best_r=round(best, 1),
        max_dd=round(max_dd, 1),
        no_win_run=mx,
        open_n=len(op), unreal_r=round(sum(t["unreal_r"] for t in op), 2),
        candidates=c["cand"], wrong_loc=c["loc"], no_fill=c["expired"], fakeouts=c["fake"], wide_skip=c["wide"],
    )


def yearly_table(trades: pd.DataFrame) -> pd.DataFrame:
    """Net R per coin per year (year of the entry), plus a BASKET row."""
    if trades.empty:
        return pd.DataFrame()
    t = trades.copy()
    t["year"] = pd.to_datetime(t["entry_time"]).dt.year
    pv = t.pivot_table(index="coin", columns="year", values="r", aggfunc="sum", fill_value=0.0).round(1)
    pv.loc["BASKET"] = pv.sum().round(1)
    return pv


def basket_summary(per_coin: pd.DataFrame, trades: pd.DataFrame | None = None) -> dict:
    """One line per parameter set: how it does across the whole coin basket."""
    if per_coin.empty:
        return {}
    return dict(
        coins=len(per_coin),
        trades=int(per_coin["trades"].sum()),
        net_r=round(per_coin["net_r"].sum(), 1),
        net_long=round(per_coin["net_long"].sum(), 1),
        net_short=round(per_coin["net_short"].sum(), 1),
        sum_wo_best=round(per_coin["net_wo_best"].sum(), 1),
        pos_coins=int((per_coin["net_r"] > 0).sum()),
        pos_wo_best=int((per_coin["net_wo_best"] > 0).sum()),
        median_exp=round(per_coin["exp_r"].median(), 3),
        worst_dd=round(per_coin["max_dd"].max(), 1),
        worst_no_win=int(per_coin["no_win_run"].max()),
        **_year_bits(trades),
    )


def _year_bits(trades) -> dict:
    if trades is None or trades.empty:
        return dict(worst_year=0.0, pos_years="-")
    y = trades.groupby(pd.to_datetime(trades["entry_time"]).dt.year)["r"].sum()
    return dict(worst_year=round(float(y.min()), 1), pos_years=f"{int((y > 0).sum())}/{len(y)}")


def score(b: dict) -> tuple:
    """Ranking key: robustness first (coins still positive without their best trade), then size."""
    if not b:
        return (-1, -1e9, -1e9)
    # coins still positive without their best trade -> worst calendar year of the basket -> total without best trades
    return (b["pos_wo_best"], b.get("worst_year", 0.0), b["sum_wo_best"])

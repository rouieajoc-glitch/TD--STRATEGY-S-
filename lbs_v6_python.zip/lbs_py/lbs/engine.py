"""
LB-S v6 engine - Python port of the Pine script "LB-S v6: SMC structure + Level Body runner".

Bar-by-bar, no lookahead. Rules are kept identical to the Pine version:
  * structure engine = the LuxAlgo-style leg engine from CA-SMC+LB v20.1
    (internal length 5, swing length 50, confluence filter on internal breaks)
  * Level Body = red->green (bull) or green->red (bear) whose bodies meet (|close[1]-open| <= tol*ATR)
  * setup location, stops, runner / fixed exits, fees and stats match the Pine table.

Split in two steps so tuning is fast:
  build_features(df, StructParams, LBParams)  -> per-bar structure + LB arrays (heavy, cached)
  simulate(features, TradeParams, start, end)  -> list of closed trades + open trades (light)
"""
from __future__ import annotations

from dataclasses import dataclass, asdict
import math

import numpy as np
import pandas as pd

NAN = float("nan")


# --------------------------------------------------------------------------- params
@dataclass(frozen=True)
class StructParams:
    int_len: int = 5          # Internal structure length
    swing_len: int = 50       # Swing (external) structure length
    confluence: bool = True   # confluence filter on internal breaks (original LuxAlgo formula)


@dataclass(frozen=True)
class LBParams:
    tol_mult: float = 0.05     # body meet tolerance (x ATR)
    use_size: bool = True
    size_mode: str = "either"  # "either" | "both"
    min_body_pct: float = 0.15
    no_doji: bool = True
    doji_ratio: float = 0.30


@dataclass(frozen=True)
class TradeParams:
    # setup location
    setup: str = "pullback"    # any | with_trend | pullback | after_swing_choch | int_choch_with_trend
    fresh_n: int = 30          # N bars for the two CHoCH modes
    need_plus: bool = False    # CHoCH must be CHoCH+
    use_disc: bool = False     # LB in discount (long) / premium (short) of the swing range
    direction: str = "both"    # both | long | short
    # entry
    entry: str = "limit"       # limit (bot) | sweep_close
    sweep_n: int = 3
    # stop
    stop: str = "pullback"     # pullback | pattern | atr | fixed
    sl_look: int = 2
    atr_mult: float = 1.5
    fix_pct: float = 5.0
    sl_buf: float = 0.1
    min_sl_pct: float = 0.5
    max_sl_pct: float = 0.0    # 0 = off
    # exit
    exit: str = "runner"       # runner | fixed
    tp_r: float = 3.0
    be_at: float = 1.5         # 99 = never
    be_off: float = 0.1
    trail: str = "internal"    # internal | swing | atr
    trail_start: float = 1.0
    tr_atr: float = 3.0
    fee_pct: float = 0.1       # round trip %

    def short_name(self) -> str:
        return (f"{self.setup}|{self.direction}|stop={self.stop}|exit={self.exit}"
                f"|be={self.be_at}|trail={self.trail}@{self.trail_start}")


def params_dict(*ps) -> dict:
    out = {}
    for p in ps:
        out.update(asdict(p))
    return out


# --------------------------------------------------------------------------- helpers
def atr_rma(h: np.ndarray, l: np.ndarray, c: np.ndarray, n: int = 14) -> np.ndarray:
    """ta.atr(14): RMA of true range, seeded with an SMA (same as Pine)."""
    size = len(h)
    tr = np.empty(size)
    tr[0] = h[0] - l[0]
    if size > 1:
        pc = c[:-1]
        tr[1:] = np.maximum.reduce([h[1:] - l[1:], np.abs(h[1:] - pc), np.abs(l[1:] - pc)])
    out = np.full(size, NAN)
    if size >= n:
        out[n - 1] = tr[:n].mean()
        a = 1.0 / n
        for i in range(n, size):
            out[i] = a * tr[i] + (1 - a) * out[i - 1]
    return out


def _neq(a: float, b: float) -> bool:
    """Pine 'a != b' where na makes the condition false."""
    return not (math.isnan(a) or math.isnan(b)) and a != b


def _legs(h: np.ndarray, l: np.ndarray, size: int) -> np.ndarray:
    """legOf(size): 0 = bearish leg started (new high 'size' bars ago), 1 = bullish leg."""
    n = len(h)
    hh = pd.Series(h).rolling(size).max().to_numpy()   # ta.highest(size), current bar included
    ll = pd.Series(l).rolling(size).min().to_numpy()
    lg = np.zeros(n, dtype=np.int8)
    cur = 0
    for t in range(n):
        if t >= size:
            if h[t - size] > hh[t]:
                cur = 0
            elif l[t - size] < ll[t]:
                cur = 1
        lg[t] = cur
    return lg


# --------------------------------------------------------------------------- features
def build_features(df: pd.DataFrame, sp: StructParams = StructParams(), lp: LBParams = LBParams()) -> dict:
    """Per-bar state exactly as the Pine script sees it at the close of each bar."""
    o = df["open"].to_numpy(float)
    h = df["high"].to_numpy(float)
    l = df["low"].to_numpy(float)
    c = df["close"].to_numpy(float)
    n = len(df)
    atr = atr_rma(h, l, c, 14)

    leg_sw = _legs(h, l, sp.swing_len)
    leg_in = _legs(h, l, sp.int_len)

    # pivot state (cur, last, scr, bar) for swing / internal highs and lows
    swH_cur = swH_last = swL_cur = swL_last = NAN
    inH_cur = inH_last = inL_cur = inL_last = NAN
    swH_scr = swL_scr = inH_scr = inL_scr = False
    swH_bar = swL_bar = inH_bar = inL_bar = -1

    a_inH = np.full(n, NAN); a_inL = np.full(n, NAN)
    a_swH = np.full(n, NAN); a_swL = np.full(n, NAN)
    a_inHb = np.full(n, -1, dtype=np.int64); a_inLb = np.full(n, -1, dtype=np.int64)
    a_inT = np.zeros(n, dtype=np.int8); a_swT = np.zeros(n, dtype=np.int8)
    a_swChBar = np.full(n, -1, dtype=np.int64); a_swChPlus = np.zeros(n, dtype=bool)
    a_inChBar = np.full(n, -1, dtype=np.int64); a_inChPlus = np.zeros(n, dtype=bool)
    ev_sw_up = np.zeros(n, dtype=bool); ev_sw_dn = np.zeros(n, dtype=bool)
    ev_in_up = np.zeros(n, dtype=bool); ev_in_dn = np.zeros(n, dtype=bool)

    in_trend = sw_trend = 0
    sw_ch_bar = in_ch_bar = -1
    sw_ch_plus = in_ch_plus = False

    up_wick = h - np.maximum(c, o)
    lo_wick = np.minimum(c, o - l)          # original LuxAlgo formula (fixWick off)
    st_bull = (~np.full(n, sp.confluence)) | (up_wick > lo_wick)
    st_bear = (~np.full(n, sp.confluence)) | (up_wick < lo_wick)

    S, I = sp.swing_len, sp.int_len
    for t in range(n):
        # ---- updatePivots(swingLen) then updatePivots(intLen)
        if t >= 1:
            chg = int(leg_sw[t]) - int(leg_sw[t - 1])
            if chg == 1 and t >= S:
                swL_last, swL_cur, swL_scr, swL_bar = swL_cur, l[t - S], False, t - S
            elif chg == -1 and t >= S:
                swH_last, swH_cur, swH_scr, swH_bar = swH_cur, h[t - S], False, t - S
            chg = int(leg_in[t]) - int(leg_in[t - 1])
            if chg == 1 and t >= I:
                inL_last, inL_cur, inL_scr, inL_bar = inL_cur, l[t - I], False, t - I
            elif chg == -1 and t >= I:
                inH_last, inH_cur, inH_scr, inH_bar = inH_cur, h[t - I], False, t - I
        a_inH[t], a_inL[t], a_swH[t], a_swL[t] = inH_cur, inL_cur, swH_cur, swL_cur
        a_inHb[t], a_inLb[t] = inH_bar, inL_bar

        # ---- crossovers (series value of the pivot on this bar and the previous bar)
        if t >= 1:
            x_inH = c[t] > a_inH[t] and c[t - 1] <= a_inH[t - 1]
            x_inL = c[t] < a_inL[t] and c[t - 1] >= a_inL[t - 1]
            x_swH = c[t] > a_swH[t] and c[t - 1] <= a_swH[t - 1]
            x_swL = c[t] < a_swL[t] and c[t - 1] >= a_swL[t - 1]
        else:
            x_inH = x_inL = x_swH = x_swL = False

        # ---- internal breaks
        if x_inH and not inH_scr and _neq(inH_cur, swH_cur) and st_bull[t]:
            if in_trend == -1:
                ev_in_up[t] = True
                in_ch_bar = t
                in_ch_plus = (inH_cur < inH_last) and (inL_cur < inL_last)
            in_trend = 1
            inH_scr = True
        if x_inL and not inL_scr and _neq(inL_cur, swL_cur) and st_bear[t]:
            if in_trend == 1:
                ev_in_dn[t] = True
                in_ch_bar = t
                in_ch_plus = (inH_cur > inH_last) and (inL_cur > inL_last)
            in_trend = -1
            inL_scr = True
        # ---- swing breaks
        if x_swH and not swH_scr:
            if sw_trend == -1:
                ev_sw_up[t] = True
                sw_ch_bar = t
                sw_ch_plus = (swH_cur < swH_last) and (swL_cur < swL_last)
            sw_trend = 1
            swH_scr = True
        if x_swL and not swL_scr:
            if sw_trend == 1:
                ev_sw_dn[t] = True
                sw_ch_bar = t
                sw_ch_plus = (swH_cur > swH_last) and (swL_cur > swL_last)
            sw_trend = -1
            swL_scr = True

        a_inT[t], a_swT[t] = in_trend, sw_trend
        a_swChBar[t], a_swChPlus[t] = sw_ch_bar, sw_ch_plus
        a_inChBar[t], a_inChPlus[t] = in_ch_bar, in_ch_plus

    # ---- pullback extremes: lowest low since the last internal swing high (and mirror)
    pb_low = np.full(n, NAN); pb_high = np.full(n, NAN)
    for t in range(n):
        len_pl = 10 if a_inHb[t] < 0 else t - a_inHb[t] + 1
        len_ph = 10 if a_inLb[t] < 0 else t - a_inLb[t] + 1
        len_pl = max(1, min(300, len_pl)); len_ph = max(1, min(300, len_ph))
        pb_low[t] = l[max(0, t - len_pl + 1): t + 1].min()
        pb_high[t] = h[max(0, t - len_ph + 1): t + 1].max()

    # ---- Level Body candidates
    o1 = np.r_[NAN, o[:-1]]; c1 = np.r_[NAN, c[:-1]]
    h1 = np.r_[NAN, h[:-1]]; l1 = np.r_[NAN, l[:-1]]
    body0 = np.abs(c - o); body1 = np.abs(c1 - o1)
    rng0 = h - l; rng1 = h1 - l1
    with np.errstate(invalid="ignore", divide="ignore"):
        meet = np.abs(c1 - o) <= lp.tol_mult * atr
        ok0 = (body0 / c * 100 >= lp.min_body_pct) & ((not lp.no_doji) | ((rng0 > 0) & (body0 >= lp.doji_ratio * rng0)))
        ok1 = (body1 / c1 * 100 >= lp.min_body_pct) & ((not lp.no_doji) | ((rng1 > 0) & (body1 >= lp.doji_ratio * rng1)))
    size_ok = np.ones(n, bool) if not lp.use_size else ((ok0 & ok1) if lp.size_mode == "both" else (ok0 | ok1))
    flip_up = (c1 < o1) & (c > o)
    flip_dn = (c1 > o1) & (c < o)
    base = meet & size_ok & (np.arange(n) > sp.swing_len)
    lb_px = (c1 + o) / 2

    return dict(
        time=df["time"].to_numpy(), o=o, h=h, l=l, c=c, atr=atr, n=n,
        inH=a_inH, inL=a_inL, swH=a_swH, swL=a_swL, inHb=a_inHb, inLb=a_inLb,
        inT=a_inT, swT=a_swT, swChBar=a_swChBar, swChPlus=a_swChPlus,
        inChBar=a_inChBar, inChPlus=a_inChPlus,
        ev_sw_up=ev_sw_up, ev_sw_dn=ev_sw_dn, ev_in_up=ev_in_up, ev_in_dn=ev_in_dn,
        pb_low=pb_low, pb_high=pb_high,
        bull_cand=base & flip_up, bear_cand=base & flip_dn, lb_px=lb_px,
        struct=sp, lbp=lp,
    )


# --------------------------------------------------------------------------- simulation
class _T:
    __slots__ = ("px", "dir", "born", "sl", "state", "entry", "tp", "risk", "best", "fill")

    def __init__(self, px, d, born, sl):
        self.px, self.dir, self.born, self.sl = px, d, born, sl
        self.state = 0
        self.entry = self.tp = self.risk = self.best = NAN
        self.fill = -1


def simulate(F: dict, tp: TradeParams = TradeParams(), start=None, end=None) -> dict:
    """Run the v6 trade logic. start/end (any pandas-parsable date) limit where NEW LBs may form,
    like the Pine 'Test start / Test end' inputs; trades opened inside the window run to their exit."""
    n = F["n"]; o, h, l, c, atr = F["o"], F["h"], F["l"], F["c"], F["atr"]
    times = F["time"]
    t0 = np.datetime64(pd.Timestamp(start).tz_localize(None)) if start is not None else None
    t1 = np.datetime64(pd.Timestamp(end).tz_localize(None)) if end is not None else None

    lo_n = pd.Series(l).rolling(tp.sl_look, min_periods=1).min().to_numpy()
    hi_n = pd.Series(h).rolling(tp.sl_look, min_periods=1).max().to_numpy()
    inH, inL, swH, swL = F["inH"], F["inL"], F["swH"], F["swL"]
    inHb, inLb = F["inHb"], F["inLb"]
    inT, swT = F["inT"], F["swT"]
    swChBar, swChPlus, inChBar, inChPlus = F["swChBar"], F["swChPlus"], F["inChBar"], F["inChPlus"]
    pb_low, pb_high = F["pb_low"], F["pb_high"]
    bull_cand, bear_cand, lb_px = F["bull_cand"], F["bear_cand"], F["lb_px"]

    is_limit = tp.entry == "limit"
    is_runner = tp.exit == "runner"
    buf = tp.sl_buf
    allow_long = tp.direction != "short"
    allow_short = tp.direction != "long"

    active: list[_T] = []
    closed = []
    cnt = dict(cand=0, loc=0, wide=0, expired=0, fake=0)

    def stop_for(d, entry_px, t):
        if tp.stop == "pullback":
            s = (min(pb_low[t], l[t]) - buf * atr[t]) if d == 1 else (max(pb_high[t], h[t]) + buf * atr[t])
        elif tp.stop == "pattern":
            s = (lo_n[t] - buf * atr[t]) if d == 1 else (hi_n[t] + buf * atr[t])
        elif tp.stop == "atr":
            s = entry_px - d * tp.atr_mult * atr[t]
        else:
            s = entry_px * (1 - d * tp.fix_pct / 100)
        min_d = entry_px * tp.min_sl_pct / 100
        return min(s, entry_px - min_d) if d == 1 else max(s, entry_px + min_d)

    def open_trade(f: _T, entry_px, sl_px, t):
        f.entry, f.sl = entry_px, sl_px
        f.risk = max(abs(sl_px - entry_px), abs(entry_px) * 1e-9)
        f.best = entry_px
        f.tp = NAN if is_runner else entry_px + f.dir * tp.tp_r * f.risk
        f.state, f.fill = 1, t

    for t in range(n):
        # ---------------- manage pending / open trades (newest first, like the Pine loop)
        keep = []
        for f in reversed(active):
            drop = False
            if f.state == 0:
                if is_limit:
                    if (h[t] >= f.px) if f.dir == -1 else (l[t] <= f.px):
                        open_trade(f, f.px, f.sl, t)
                else:
                    pierced = (h[t] > f.px) if f.dir == -1 else (l[t] < f.px)
                    back = (c[t] <= f.px) if f.dir == -1 else (c[t] >= f.px)
                    if pierced and back:
                        s = max(f.sl, h[t] + buf * atr[t]) if f.dir == -1 else min(f.sl, l[t] - buf * atr[t])
                        open_trade(f, c[t], s, t)
                    elif not back:
                        cnt["fake"] += 1
                        drop = True
                if not drop and f.state == 0 and t - f.born >= tp.sweep_n:
                    cnt["expired"] += 1
                    drop = True

            if not drop and f.state == 1:
                fresh = t == f.fill
                sl_hit = (is_limit or not fresh) and ((h[t] >= f.sl) if f.dir == -1 else (l[t] <= f.sl))
                tp_hit = (not is_runner) and (not fresh) and ((l[t] <= f.tp) if f.dir == -1 else (h[t] >= f.tp))
                exit_r = None
                if sl_hit:
                    if fresh:
                        x = f.sl
                    else:
                        x = min(f.sl, o[t]) if f.dir == 1 else max(f.sl, o[t])
                    exit_r = (x - f.entry) * f.dir / f.risk
                    reason = "stop"
                elif tp_hit:
                    exit_r = tp.tp_r
                    reason = "tp"
                if exit_r is not None:
                    exit_r -= tp.fee_pct / 100 * f.entry / f.risk
                    closed.append(dict(
                        dir=f.dir, lb_time=times[f.born], entry_time=times[f.fill], exit_time=times[t],
                        entry=f.entry, risk=f.risk, risk_pct=f.risk / f.entry * 100,
                        r=exit_r, bars=t - f.fill, reason=reason, exit_bar=t))
                    drop = True
                elif is_runner and not fresh:
                    f.best = max(f.best, h[t]) if f.dir == 1 else min(f.best, l[t])
                    run_r = (f.best - f.entry) * f.dir / f.risk
                    new_sl = f.sl
                    if run_r >= tp.be_at:
                        be_lvl = f.entry + f.dir * tp.be_off * f.risk
                        new_sl = max(new_sl, be_lvl) if f.dir == 1 else min(new_sl, be_lvl)
                    if run_r >= tp.trail_start:
                        if tp.trail == "atr":
                            tr = f.best - f.dir * tp.tr_atr * atr[t]
                        elif tp.trail == "internal":
                            if f.dir == 1:
                                tr = inL[t] - buf * atr[t] if inLb[t] > f.born else NAN
                            else:
                                tr = inH[t] + buf * atr[t] if inHb[t] > f.born else NAN
                        else:
                            tr = (swL[t] - buf * atr[t]) if f.dir == 1 else (swH[t] + buf * atr[t])
                        if not math.isnan(tr) and ((tr < c[t]) if f.dir == 1 else (tr > c[t])):
                            new_sl = max(new_sl, tr) if f.dir == 1 else min(new_sl, tr)
                    f.sl = new_sl
            if not drop:
                keep.append(f)
        active = list(reversed(keep))

        # ---------------- detect a new LB
        in_win = (t0 is None or times[t] >= t0) and (t1 is None or times[t] <= t1)
        if not in_win:
            continue
        bc = bull_cand[t] and allow_long
        sc = bear_cand[t] and allow_short
        if not (bc or sc):
            continue
        cnt["cand"] += 1
        d = 1 if bc else -1
        st, it = swT[t], inT[t]
        sw_ok = swChBar[t] >= 0 and t - swChBar[t] <= tp.fresh_n and (not tp.need_plus or swChPlus[t])
        in_ok = inChBar[t] >= 0 and t - inChBar[t] <= tp.fresh_n and (not tp.need_plus or inChPlus[t])
        if tp.setup == "any":
            loc = True
        elif tp.setup == "with_trend":
            loc = st == d
        elif tp.setup == "pullback":
            loc = st == d and it == -d
        elif tp.setup == "after_swing_choch":
            loc = st == d and sw_ok
        else:  # int_choch_with_trend
            loc = st == d and it == d and in_ok
        px = lb_px[t]
        if loc and tp.use_disc:
            mid = (swH[t] + swL[t]) / 2
            loc = (not math.isnan(mid)) and ((px <= mid) if d == 1 else (px >= mid))
        if not loc:
            cnt["loc"] += 1
            continue
        sl0 = stop_for(d, px, t)
        if tp.max_sl_pct > 0 and abs(px - sl0) / px * 100 > tp.max_sl_pct:
            cnt["wide"] += 1
            continue
        active.append(_T(px, d, t, sl0))

    open_trades = [dict(dir=f.dir, entry=f.entry, entry_time=times[f.fill],
                        unreal_r=(c[-1] - f.entry) * f.dir / f.risk) for f in active if f.state == 1]
    closed.sort(key=lambda x: x["exit_bar"])
    return dict(trades=closed, open=open_trades, counts=cnt)

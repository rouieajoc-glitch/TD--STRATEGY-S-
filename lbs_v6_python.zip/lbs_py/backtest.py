#!/usr/bin/env python3
"""
One LB-S v6 configuration on the whole coin basket - the same table you see in TradingView, one row per coin.

Examples
  python backtest.py                                   # v6 Pine defaults, 1D, 10 coins, Binance spot
  python backtest.py --direction long --end 2024-12-31
  python backtest.py --interval 4h --setup after_swing_choch --fresh-n 40 --trail swing
  python backtest.py --coins ETH BTC --save-trades
  python backtest.py --direction long --regime btc_sma      # longs only while BTC is above its 200-day MA
"""
import argparse
from dataclasses import asdict
import json
import os

from lbs import DEFAULT_COINS
from lbs.runner import Basket, add_param_args, params_from_args, print_table, print_basket, print_years, out_dir


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--coins", nargs="+", default=DEFAULT_COINS)
    ap.add_argument("--interval", default="1d", help="1d, 4h, 1h ... (Binance interval)")
    ap.add_argument("--source", default="spot", choices=["spot", "futures", "csv", "synthetic"])
    ap.add_argument("--start", default="2020-01-01", help="LBs may form from this date (Pine 'Test start')")
    ap.add_argument("--end", default=None, help="LBs may form until this date (Pine 'Test end')")
    ap.add_argument("--refresh", action="store_true", help="re-download all candles")
    ap.add_argument("--save-trades", action="store_true")
    add_param_args(ap)
    args = ap.parse_args()

    tp, sp = params_from_args(args)
    print(f"Loading {args.interval} candles ({args.source})...")
    basket = Basket(args.coins, args.interval, args.source, args.refresh)
    per, b, trades = basket.run(tp, sp, args.start, args.end, keep_trades=args.save_trades)

    print_table(per, f"LB-S v6 | {args.interval} | {args.start} -> {args.end or 'now'}")
    print_basket(b)
    print_years(trades, "entry year")
    print("\nsettings:", json.dumps({**asdict(sp), **asdict(tp)}))

    d = out_dir("backtest")
    tag = f"{args.interval}_{args.start}_{args.end or 'now'}"
    per.to_csv(os.path.join(d, f"per_coin_{tag}.csv"), index=False)
    if args.save_trades and not trades.empty:
        trades.to_csv(os.path.join(d, f"trades_{tag}.csv"), index=False)
    print(f"saved to {d}")


if __name__ == "__main__":
    main()

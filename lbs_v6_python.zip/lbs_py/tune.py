#!/usr/bin/env python3
"""
Staged tuner for LB-S v6 - one setting at a time, judged on the WHOLE basket, with a held-out period.

  1. In-sample  (default 2020-01-01 -> 2024-12-31): every stage tries its options with all other settings
     fixed, keeps the best one, moves on.
  2. Out-of-sample (default 2025-01-01 -> now): the final settings are run ONCE on data the tuner never saw.
     If it still makes money there, the edge is probably real. If it falls apart, it was curve-fitted.

Ranking (most robust first): coins still positive WITHOUT their best trade -> total R without each
coin's best trade -> smaller worst drawdown.  A setting only replaces the current one if it ranks higher.

Examples
  python tune.py                         # 1D, long only, 10 coins
  python tune.py --interval 4h
  python tune.py --direction both
  python tune.py --stages setup trail     # only some stages
"""
import argparse
from dataclasses import asdict, replace
import json
import os
import time

import pandas as pd

from lbs import DEFAULT_COINS, StructParams, TradeParams, score
from lbs.runner import Basket, print_table, print_basket, out_dir

STAGES = {
    "setup": [
        dict(setup="pullback"),
        dict(setup="with_trend"),
        dict(setup="after_swing_choch", fresh_n=20),
        dict(setup="after_swing_choch", fresh_n=40),
        dict(setup="after_swing_choch", fresh_n=80),
        dict(setup="int_choch_with_trend", fresh_n=5),
        dict(setup="int_choch_with_trend", fresh_n=15),
        dict(setup="any"),                      # reference: no structure at all
    ],
    "trail": [
        dict(trail="internal"),
        dict(trail="swing"),
        dict(trail="atr", tr_atr=3.0),
        dict(trail="atr", tr_atr=5.0),
    ],
    "trail_start": [dict(trail_start=x) for x in (0.0, 1.0, 2.0, 3.0)],
    "break_even": [dict(be_at=x) for x in (1.0, 1.5, 3.0, 99.0)],
    "stop": [
        dict(stop="pullback"),
        dict(stop="atr", atr_mult=1.5),
        dict(stop="atr", atr_mult=2.0),
        dict(stop="atr", atr_mult=3.0),
        dict(stop="pattern"),
    ],
    "structure": [dict(int_len=i, swing_len=s) for i in (3, 5, 8) for s in (20, 30, 50)],
    "confluence": [dict(confluence=True), dict(confluence=False)],
}
STRUCT_KEYS = {"int_len", "swing_len", "confluence"}


def label(opt: dict) -> str:
    return " ".join(f"{k}={v}" for k, v in opt.items())


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--coins", nargs="+", default=DEFAULT_COINS)
    ap.add_argument("--interval", default="1d")
    ap.add_argument("--source", default="spot", choices=["spot", "futures", "csv", "synthetic"])
    ap.add_argument("--direction", default="long", choices=["long", "short", "both"], help="spot = long")
    ap.add_argument("--is-start", default="2020-01-01")
    ap.add_argument("--is-end", default="2024-12-31")
    ap.add_argument("--oos-start", default="2025-01-01")
    ap.add_argument("--oos-end", default=None)
    ap.add_argument("--min-trades", type=int, default=30, help="ignore options with fewer basket trades in-sample")
    ap.add_argument("--stages", nargs="+", default=list(STAGES), choices=list(STAGES))
    ap.add_argument("--fee-pct", type=float, default=0.1, help="round trip %%, spot is about 0.2")
    ap.add_argument("--refresh", action="store_true")
    args = ap.parse_args()

    t_start = time.time()
    print(f"Loading {args.interval} candles ({args.source})...")
    basket = Basket(args.coins, args.interval, args.source, args.refresh)
    if not basket.data:
        raise SystemExit("no data loaded")

    tp = TradeParams(direction=args.direction, fee_pct=args.fee_pct)
    sp = StructParams()
    run_dir = out_dir(f"tune_{args.interval}_{time.strftime('%Y%m%d_%H%M')}")
    stage_rows = []

    def evaluate(tp_, sp_):
        per, b, _ = basket.run(tp_, sp_, args.is_start, args.is_end)
        return per, b

    _, cur_b = evaluate(tp, sp)
    print(f"\nStart (v6 defaults, {args.direction}) in-sample {args.is_start} -> {args.is_end}")
    print_basket(cur_b, "START")

    for stage in args.stages:
        print(f"\n##### stage: {stage}")
        results = []
        for opt in STAGES[stage]:
            s_kw = {k: v for k, v in opt.items() if k in STRUCT_KEYS}
            t_kw = {k: v for k, v in opt.items() if k not in STRUCT_KEYS}
            tp_try, sp_try = replace(tp, **t_kw), replace(sp, **s_kw)
            _, b = evaluate(tp_try, sp_try)
            ok = b and b["trades"] >= args.min_trades
            results.append((opt, tp_try, sp_try, b, ok))
            row = {"stage": stage, "option": label(opt), **b, "eligible": ok}
            stage_rows.append(row)

        tbl = pd.DataFrame([{"option": label(o), **b, "ok": ok} for o, _, _, b, ok in results])
        tbl = tbl.sort_values(["pos_wo_best", "sum_wo_best"], ascending=False)
        cols = ["option", "trades", "net_r", "net_long", "net_short", "sum_wo_best", "pos_wo_best",
                "median_exp", "worst_dd", "worst_no_win", "ok"]
        with pd.option_context("display.width", 250, "display.max_columns", 30):
            print(tbl[cols].to_string(index=False))

        eligible = [r for r in results if r[4]]
        if not eligible:
            print("  no option has enough trades - keeping current settings")
            continue
        best = max(eligible, key=lambda r: score(r[3]))
        if score(best[3]) > score(cur_b):
            tp, sp, cur_b = best[1], best[2], best[3]
            print(f"  -> keep: {label(best[0])}")
        else:
            print("  -> nothing beats the current settings, keeping them")

    pd.DataFrame(stage_rows).to_csv(os.path.join(run_dir, "stages_in_sample.csv"), index=False)

    # ---------------- final: in-sample vs out-of-sample
    final = {**asdict(sp), **asdict(tp)}
    print("\n\n================ FINAL SETTINGS ================")
    print(json.dumps(final, indent=1))
    with open(os.path.join(run_dir, "best_settings.json"), "w") as fh:
        json.dump(final, fh, indent=1)

    per_is, b_is, tr_is = basket.run(tp, sp, args.is_start, args.is_end, keep_trades=True)
    per_oos, b_oos, tr_oos = basket.run(tp, sp, args.oos_start, args.oos_end, keep_trades=True)
    print_table(per_is, f"IN-SAMPLE {args.is_start} -> {args.is_end}")
    print_basket(b_is, "IN-SAMPLE")
    print_table(per_oos, f"OUT-OF-SAMPLE {args.oos_start} -> {args.oos_end or 'now'}  (never used for tuning)")
    print_basket(b_oos, "OUT-OF-SAMPLE")

    per_is.to_csv(os.path.join(run_dir, "final_in_sample.csv"), index=False)
    per_oos.to_csv(os.path.join(run_dir, "final_out_of_sample.csv"), index=False)
    if not tr_is.empty:
        tr_is.to_csv(os.path.join(run_dir, "trades_in_sample.csv"), index=False)
    if not tr_oos.empty:
        tr_oos.to_csv(os.path.join(run_dir, "trades_out_of_sample.csv"), index=False)

    # simple verdict
    if b_oos and b_oos["trades"] > 0:
        held = b_oos["net_r"] > 0 and b_oos["pos_coins"] >= max(1, b_oos["coins"] // 2)
        print("\nVERDICT:", "edge HELD out-of-sample" if held else "edge did NOT hold out-of-sample - treat as curve-fit",
              f"(OOS net {b_oos['net_r']}R over {b_oos['trades']} trades, {b_oos['pos_coins']}/{b_oos['coins']} coins positive)")
    print(f"\nTo rebuild these settings in TradingView (LB-S v6 inputs): see {os.path.join(run_dir, 'best_settings.json')}")
    print(f"done in {time.time() - t_start:.0f}s, results in {run_dir}")


if __name__ == "__main__":
    main()

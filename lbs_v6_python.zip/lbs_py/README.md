# LB-S v6 — Python backtester and tuner

Python port of the TradingView script **LB-S v6: SMC structure + Level Body runner**.
Same rules, bar by bar, no lookahead:

- **Structure engine**: the leg engine from CA-SMC+LB v20.1 (internal length 5, swing length 50, confluence filter, CHoCH / CHoCH+).
- **Level Body**: red→green (long) or green→red (short) candles whose bodies meet, with the size/doji filter.
- **Setup location**: any, with swing trend, pullback in swing trend, first N bars after swing CHoCH, internal CHoCH back with swing trend.
- **Regime filter** (`--regime btc_sma` or `coin_sma`, `--regime-len 200`): longs only while BTC (or the coin) closes above its moving average, shorts only below. This is not in the Pine version yet.
- **Entry**: a limit order at the LB level, filled within N bars (like the bot), or at the close of the sweep candle.
- **Stops**: pullback low/high, pattern, ATR multiple, or fixed %.
- **Exits**: Runner (break-even, then a trail on internal structure, swing structure or ATR) or fixed TP. Fees are counted in R.
- **Stats**: the same as the TradingView table (W/BE/L, net R, long/short, net R without the best trade, PF, expectancy, max drawdown, longest run without a win).

## Setup in Codespaces

```bash
pip install -r requirements.txt
```

## 1) Backtest one configuration

```bash
python backtest.py                                    # v6 defaults, 1D, 10 coins, Binance spot
python backtest.py --direction long --end 2024-12-31
python backtest.py --interval 4h --setup after_swing_choch --fresh-n 40 --trail swing
python backtest.py --coins ETH BTC SOL --save-trades
python backtest.py --help                             # every setting
```

Every LB-S v6 input is a flag, for example `--setup`, `--stop atr --atr-mult 2`, `--be-at 99`, `--trail swing`,
`--int-len 3 --swing-len 30` or `--fee-pct 0.2`.

## 2) Tune (the main tool)

```bash
python tune.py                      # 1D, long only, tune on 2020-2024, test once on 2025 -> now
python tune.py --interval 4h
python tune.py --fee-pct 0.2        # spot fees
python tune.py --stages setup trail break_even
```

The tuner works in stages: regime → setup → trail → trail start → break-even → stop → structure lengths → confluence filter.
Each stage tries its options with every other setting fixed, judges them on the **whole basket**, keeps the best, then moves on.

It ranks options by robustness, not by the biggest number:
1. how many coins are still positive **without their single best trade**
2. the basket's **worst calendar year**, which rewards surviving bear markets like 2022
3. total net R without each coin's best trade

At the end it runs the final settings **once** on the out-of-sample period (2025 → now), which the tuner never saw.

- **Edge HELD**: the settings are probably real.
- **Did NOT hold**: they were curve-fitted, or the market changed. The last line also runs the *untuned* v6 defaults on the same period, so you can tell which:
  - If the defaults lose just as much, it's the market regime, not the tuning.
  - Both runs also print a **net R per year** table.

Results go to `results/tune_<interval>_<date>/`:
- `stages_in_sample.csv`: every option of every stage
- `best_settings.json`: the winning settings
- `final_in_sample.csv` / `final_out_of_sample.csv`: the per-coin tables
- `trades_*.csv`: every trade, for your own checks

## Data

- `--source spot` (default): Binance spot candles from `data-api.binance.vision`. This mirror isn't blocked in the US, where Codespaces usually run.
- `--source futures`: Binance USDT-M perps (`fapi.binance.com`). Binance blocks this from US servers (HTTP 451), so use it only outside the US.
- `--source csv`: put `data/<SYMBOL>_<interval>.csv` there yourself, with columns `time,open,high,low,close`.
- `--source synthetic`: random prices, only for checking that everything runs.

Candles are cached in `data/`, and later runs only download the new candles. Use `--refresh` to re-download everything.

Spot prices differ slightly from the TradingView `.P` perp charts, and some coins have a different spot listing date. So expect trade counts close to TradingView's, not identical.

## Settings → LB-S v6 inputs in TradingView

| JSON key | TradingView input |
|---|---|
| `int_len`, `swing_len`, `confluence` | Structure engine |
| `setup`: `any` / `with_trend` / `pullback` / `after_swing_choch` / `int_choch_with_trend` | Where the LB must form: Any / With swing trend / Pullback in swing trend / First N bars after swing CHoCH / Internal CHoCH back with swing trend |
| `fresh_n`, `need_plus`, `use_disc`, `direction` | N bars, CHoCH+, discount, Direction |
| `entry`: `limit` / `sweep_close`, `sweep_n` | Entry, Fill / sweep window |
| `stop`: `pullback` / `pattern` / `atr` / `fixed`, plus `atr_mult`, `fix_pct`, `sl_buf`, `min_sl_pct`, `max_sl_pct` | Stop group |
| `exit`: `runner` / `fixed`, plus `tp_r`, `be_at`, `be_off`, `trail`, `trail_start`, `tr_atr`, `fee_pct` | Exit group |

## Notes

- Trades can overlap. Every LB that forms opens its own trade, as in the Pine version. For the live bot (one trade at a time), check `trades_*.csv`.
- Risk per trade: the "max drawdown R" and "longest run without a win" columns tell you how small 1R has to be. A 60R drawdown at 0.5% risk per trade is −30%.
